
import './App.css';
import Header from './Commponent/Header/Header';
import Followers from './Commponent/Followers/Followers';
import { useEffect, useState } from 'react';
import Overview from './Commponent/Overview/Overview';
import Headeroverview from './Commponent/headeroverview';


function App() {

  const [ArrayOfObject, setArrayOfObject] = useState([]);

  useEffect (() =>{
      function CallApi (){
          fetch("http://localhost:3000/followers")
          
          .then ((response) => {return response.json(); })

          .then((finalResult) => {
              setArrayOfObject(finalResult);
          });
      } CallApi(); [] }) ;

      const [ArrayOfengagement, setArrayOfengagement] = useState([])
      useEffect (() => {
          function CallApi (){
            fetch("http://localhost:3000/engagement")
            .then ((response) =>{return response.json(); })
      
            .then((finnal) =>{
              setArrayOfengagement(finnal);
            });
          } CallApi(); [] }) ;    
      

  return (
    <>
    <div id="patern">
      
    </div>
    <div id='dachbord'>
     <Header/>
     <div id="stylfollow">
      {ArrayOfObject.map((follower) => {
        return (
          <Followers
           key = {follower.id}
           platform = {follower.Pic}
           username = {follower.username}
            value = {follower.value}
            metric = {follower.metric}
            icon = {follower.Icon}
            change = {follower.change}
          > </Followers>
        );
      })}
     </div>
     <>
     <Headeroverview></Headeroverview>
      <div id="overviewstyle">
      {ArrayOfengagement.map((overview) =>{
        return (
          <Overview
           key = {overview.id}
           platform = {overview.platform}
            value = {overview.value}
            metric = {overview.metric}
            icon = {overview.Icon}
            change = {overview.change}
          ></Overview>
        )
      })}
     </div>
     </>
    
    </div>
    </>
    
  )
}

export default App
