
import './Followers.css';
function Followers (props) {
  
  
    return (
        <button id="label">
            <div>
             <img src={props.Pic}></img>
            <span>{props.username}</span>   
            </div>
            <h1>{props.value}</h1>
            <p>{props.metric}</p>
            <div>
                <img src={props.Icon}/>
                <span>{props.change}</span>
            </div>
        </button>
    )
}
export default Followers;